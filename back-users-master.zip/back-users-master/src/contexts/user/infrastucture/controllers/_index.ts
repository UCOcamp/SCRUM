import RegisterUserController from './RegisterUser.controller';

const UserControllers = [RegisterUserController];

export default UserControllers;
