const mongoConfig = {
  HOST: 'localhost:27017',
  NAME: 'ucocamp-users',
};

export default mongoConfig;
